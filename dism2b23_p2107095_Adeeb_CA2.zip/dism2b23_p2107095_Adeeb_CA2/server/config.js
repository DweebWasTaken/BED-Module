/*
  Name: Adeeb
  Class: DISM/FT/2B/23
  Group: None (Solo)
  Admin No: P2107095
*/

//var secret = 'abc13nmmAXz'; //your own secret key
var secretKey = 'dfkhfkda6812683216jcxzm876875@!#@$dsd';
module.exports = secretKey;