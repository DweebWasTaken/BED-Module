Instructions are inside the documents

•	Open the zip and open the extracted folder in Visual Studio Code
•	Open the Dump_SPair files, and import it.
•	On the databaseConfig.js file located in the model folder, change the password to your own password that you usually use in the Workbench
•	Install all the required node packages using “npm install”

Setup:
•	Right click the respective "client" and "server" folders and click on the 'Open in Integrated Terminal' option for each of the folders
•	Run nodemon on each of the terminals
•	If nodemon does not work, run the command node index.js and node server.js for the client terminal and server terminal respectively
